import os
os.system("python3 soupy-master/soupy_remastered.py")
